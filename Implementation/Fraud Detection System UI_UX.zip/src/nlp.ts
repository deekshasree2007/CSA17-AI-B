// ─── Stopwords ────────────────────────────────────────────────────────────────

export const STOPWORDS = new Set([
  "a","about","above","after","again","against","all","am","an","and","any","are",
  "arent","as","at","be","because","been","before","being","below","between","both",
  "but","by","cant","cannot","could","couldnt","did","didnt","do","does","doesnt",
  "doing","dont","down","during","each","few","for","from","further","get","gets",
  "got","had","hadnt","has","hasnt","have","havent","having","he","hed","hell",
  "hes","her","here","heres","hers","herself","him","himself","his","how","hows",
  "i","id","ill","im","ive","if","in","into","is","isnt","it","its","itself",
  "lets","me","more","most","mustnt","my","myself","no","nor","not","of","off",
  "on","once","only","or","other","ought","our","ours","ourselves","out","over",
  "own","same","shant","she","shed","shell","shes","should","shouldnt","so",
  "some","such","than","that","thats","the","their","theirs","them","themselves",
  "then","there","theres","these","they","theyd","theyll","theyre","theyve",
  "this","those","through","to","too","under","until","up","very","was","wasnt",
  "we","wed","well","were","weve","werent","what","whats","when","whens","where",
  "wheres","which","while","who","whos","whom","why","whys","will","with","wont",
  "would","wouldnt","you","youd","youll","youre","youve","your","yours","yourself",
  "yourselves","said","also","just","like","can","may","might","shall","us","re",
  "ve","ll","s","t","d","m","dont","cant","wont","isnt","arent","wasnt","werent",
  "hasnt","havent","hadnt","doesnt","didnt","wouldnt","couldnt","shouldnt",
]);

// ─── Porter-lite stemmer ──────────────────────────────────────────────────────

export function stem(word: string): string {
  if (word.length <= 3) return word;
  if (word.endsWith("ational")) return word.slice(0, -7) + "ate";
  if (word.endsWith("ization")) return word.slice(0, -7) + "ize";
  if (word.endsWith("fulness")) return word.slice(0, -7) + "ful";
  if (word.endsWith("iveness")) return word.slice(0, -7) + "ive";
  if (word.endsWith("ousness")) return word.slice(0, -7) + "ous";
  if (word.endsWith("ating"))   return word.slice(0, -5) + "ate";
  if (word.endsWith("alize"))   return word.slice(0, -5) + "al";
  if (word.endsWith("iciti"))   return word.slice(0, -5) + "ic";
  if (word.endsWith("ness"))    return word.slice(0, -4);
  if (word.endsWith("ment"))    return word.slice(0, -4);
  if (word.endsWith("tion"))    return word.slice(0, -3) + "e";
  if (word.endsWith("ance"))    return word.slice(0, -4);
  if (word.endsWith("ence"))    return word.slice(0, -4);
  if (word.endsWith("able"))    return word.slice(0, -4);
  if (word.endsWith("ible"))    return word.slice(0, -4);
  if (word.endsWith("ical"))    return word.slice(0, -4) + "ic";
  if (word.endsWith("ful"))     return word.slice(0, -3);
  if (word.endsWith("ous"))     return word.slice(0, -3);
  if (word.endsWith("ive"))     return word.slice(0, -3);
  if (word.endsWith("ize"))     return word.slice(0, -3);
  if (word.endsWith("ing") && word.length > 7) return word.slice(0, -3);
  if (word.endsWith("ies"))     return word.slice(0, -3) + "y";
  if (word.endsWith("ers"))     return word.slice(0, -2);
  if (word.endsWith("ed") && word.length > 5) return word.slice(0, -2);
  if (word.endsWith("er"))      return word.slice(0, -2);
  if (word.endsWith("ly"))      return word.slice(0, -2);
  if (word.endsWith("al"))      return word.slice(0, -2);
  if (word.endsWith("s") && !word.endsWith("ss") && word.length > 4) return word.slice(0, -1);
  return word;
}

// ─── Label detection (handles 0/1, REAL/FAKE, TRUE/FALSE, etc.) ──────────────

export interface LabelMap {
  fakeLabel: string;   // the raw CSV value that means FAKE
  realLabel: string;   // the raw CSV value that means REAL
}

export function detectLabelMap(rawLabels: string[]): LabelMap {
  // Count frequencies
  const freq = new Map<string, number>();
  for (const l of rawLabels) {
    const t = l.trim();
    if (t) freq.set(t, (freq.get(t) || 0) + 1);
  }

  const unique = [...freq.keys()];

  // Explicit pattern match — most reliable
  for (const label of unique) {
    const l = label.toLowerCase().trim();
    if (l === "fake" || l === "0" || l === "false" || l === "fabricated" || l === "unreliable") {
      const other = unique.find(x => x !== label) ?? unique[0];
      return { fakeLabel: label, realLabel: other };
    }
  }

  // "real"/"true" pattern → the OTHER one is fake
  for (const label of unique) {
    const l = label.toLowerCase().trim();
    if (l === "real" || l === "1" || l === "true" || l === "reliable" || l === "genuine") {
      const other = unique.find(x => x !== label) ?? unique[0];
      return { fakeLabel: other, realLabel: label };
    }
  }

  // Numeric: lower number = fake (0=fake, 1=real is the most common encoding)
  const nums = unique.filter(u => !isNaN(Number(u)));
  if (nums.length >= 2) {
    const sorted = [...nums].sort((a, b) => Number(a) - Number(b));
    return { fakeLabel: sorted[0], realLabel: sorted[sorted.length - 1] };
  }

  // Partial match
  const hasFake = unique.find(u => /fake|fals|unreli|satir|conspir/i.test(u));
  const hasReal = unique.find(u => /real|true|reli|genuine|legit/i.test(u));
  if (hasFake) return { fakeLabel: hasFake, realLabel: hasReal ?? unique.find(u => u !== hasFake) ?? unique[0] };
  if (hasReal) return { fakeLabel: unique.find(u => u !== hasReal) ?? unique[0], realLabel: hasReal };

  // Fallback: alphabetically first = fake
  const sorted = [...unique].sort();
  return { fakeLabel: sorted[0], realLabel: sorted[1] ?? sorted[0] };
}

export function normalizeLabel(raw: string, lmap: LabelMap): "FAKE" | "REAL" {
  return raw.trim() === lmap.fakeLabel ? "FAKE" : "REAL";
}

// ─── Text preprocessing ───────────────────────────────────────────────────────

export interface PreprocessResult {
  lowercase: string;
  noNoise: string;
  noStopwords: string;
  tokens: string[];
  stemmed: string[];
}

export function preprocess(text: string): PreprocessResult {
  const lowercase = (text || "").toLowerCase();
  // Remove URLs, punctuation, numbers, extra whitespace
  const noNoise = lowercase
    .replace(/https?:\/\/\S+/g, " ")
    .replace(/[^a-z\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  // Tokenize and filter: length > 2 and not a stopword
  const rawTokens = noNoise.split(" ").filter(t => t.length > 2 && !STOPWORDS.has(t));
  const noStopwords = rawTokens.join(" ");
  const stemmed = rawTokens.map(stem);
  return { lowercase, noNoise, noStopwords, tokens: rawTokens, stemmed };
}

// ─── Vocabulary (Map-based for O(1) lookup — critical for 20K records) ───────

export interface Vocab {
  terms: string[];
  index: Map<string, number>;   // O(1) lookup
  idf: Float32Array;
}

export function buildVocab(docs: string[][], maxFeatures = 8000, minDf = 2): Vocab {
  const df = new Map<string, number>();
  for (const d of docs) {
    const seen = new Set(d);
    for (const t of seen) df.set(t, (df.get(t) || 0) + 1);
  }
  const N = docs.length;
  const terms = [...df.entries()]
    .filter(([, f]) => f >= minDf)
    .sort((a, b) => b[1] - a[1])
    .slice(0, maxFeatures)
    .map(([w]) => w);

  const index = new Map(terms.map((w, i) => [w, i]));
  const idf = new Float32Array(terms.map(w => Math.log((N + 1) / ((df.get(w) || 0) + 1)) + 1));
  return { terms, index, idf };
}

// Sparse TF-IDF: [featureIndex, value] pairs (only non-zero)
export function sparseTfIdf(tokens: string[], vocab: Vocab): [number, number][] {
  if (!tokens.length) return [];
  const tf = new Map<number, number>();
  for (const t of tokens) {
    const idx = vocab.index.get(t);  // O(1)
    if (idx !== undefined) tf.set(idx, (tf.get(idx) || 0) + 1);
  }
  const n = tokens.length;
  const out: [number, number][] = [];
  for (const [idx, count] of tf) out.push([idx, (count / n) * vocab.idf[idx]]);
  return out;
}

function sparseDot(sparse: [number, number][], weights: Float32Array): number {
  let s = 0;
  for (const [i, v] of sparse) s += v * weights[i];
  return s;
}

// ─── Shared types ─────────────────────────────────────────────────────────────

export type AlgoName = "Naive Bayes" | "Logistic Regression" | "SVM";

export interface TrainedModel {
  algo: AlgoName;
  vocab: Vocab;
  // Naive Bayes
  logPrior?: Record<string, number>;
  logLikelihood?: Record<string, Float32Array>;
  classes?: string[];
  // LR / SVM
  weights?: Float32Array;
  bias?: number;
  positiveClass?: string;   // which label == "FAKE"
}

export interface EvalResult {
  accuracy: number;
  precision: Record<string, number>;
  recall: Record<string, number>;
  f1: Record<string, number>;
  confusionMatrix: Record<string, Record<string, number>>;
  samples: number;
}

export interface PredictResult {
  label: string;
  confidence: number;
  scores: Record<string, number>;
  topFeatures: { word: string; weight: number }[];
}

// ─── Naive Bayes ──────────────────────────────────────────────────────────────

export function trainNaiveBayes(docs: string[][], labels: string[], vocab: Vocab): TrainedModel {
  const classes = [...new Set(labels)];
  const V = vocab.terms.length;
  const logPrior: Record<string, number> = {};
  const logLikelihood: Record<string, Float32Array> = {};

  for (const cls of classes) {
    const clsIndices: number[] = [];
    for (let i = 0; i < labels.length; i++) if (labels[i] === cls) clsIndices.push(i);

    logPrior[cls] = Math.log(clsIndices.length / labels.length);

    // Word counts — use Map-based vocab index (O(1))
    const counts = new Float32Array(V).fill(1);   // Laplace smoothing
    let total = V;
    for (const i of clsIndices) {
      for (const t of docs[i]) {
        const idx = vocab.index.get(t);           // O(1) — not indexOf()
        if (idx !== undefined) { counts[idx]++; total++; }
      }
    }
    const ll = new Float32Array(V);
    for (let j = 0; j < V; j++) ll[j] = Math.log(counts[j] / total);
    logLikelihood[cls] = ll;
  }

  return { algo: "Naive Bayes", vocab, logPrior, logLikelihood, classes };
}

// ─── Logistic Regression (mini-batch SGD + L2) ───────────────────────────────

function sigmoid(x: number): number {
  return 1 / (1 + Math.exp(-Math.max(-30, Math.min(30, x))));
}

export function trainLogisticRegression(
  docs: string[][],
  labels: string[],
  vocab: Vocab,
  positiveClass: string,       // "FAKE"
  epochs = 8,
  lr = 0.2,
  lambda = 1e-4,
  batchSize = 128,
  onProgress?: (pct: number) => void,
): TrainedModel {
  const V = vocab.terms.length;
  const weights = new Float32Array(V);
  let bias = 0;
  const sparse = docs.map(d => sparseTfIdf(d, vocab));
  const y = labels.map(l => l === positiveClass ? 1 : 0);
  const n = docs.length;
  const totalBatches = epochs * Math.ceil(n / batchSize);
  let batchCount = 0;

  for (let ep = 0; ep < epochs; ep++) {
    // Shuffle indices
    const idx = Array.from({ length: n }, (_, i) => i);
    for (let i = n - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [idx[i], idx[j]] = [idx[j], idx[i]];
    }
    const epLr = lr / (1 + 0.15 * ep);

    for (let b = 0; b < n; b += batchSize) {
      const batch = idx.slice(b, b + batchSize);
      const grad = new Float32Array(V);
      let biasGrad = 0;

      for (const i of batch) {
        const err = sigmoid(sparseDot(sparse[i], weights) + bias) - y[i];
        for (const [fi, fv] of sparse[i]) grad[fi] += err * fv;
        biasGrad += err;
      }
      const bs = batch.length;
      for (let j = 0; j < V; j++) {
        weights[j] = weights[j] * (1 - epLr * lambda) - (epLr / bs) * grad[j];
      }
      bias -= (epLr / bs) * biasGrad;
      batchCount++;
      if (onProgress) onProgress(Math.round((batchCount / totalBatches) * 100));
    }
  }
  return {
    algo: "Logistic Regression", vocab, weights, bias, positiveClass,
    classes: [positiveClass, positiveClass === "FAKE" ? "REAL" : "FAKE"],
    logPrior: { [positiveClass]: 0, [positiveClass === "FAKE" ? "REAL" : "FAKE"]: 0 },
  };
}

// ─── Linear SVM — Pegasos algorithm ──────────────────────────────────────────

export function trainSVM(
  docs: string[][],
  labels: string[],
  vocab: Vocab,
  positiveClass: string,       // "FAKE"
  epochs = 10,
  C = 1.5,
  batchSize = 64,
  onProgress?: (pct: number) => void,
): TrainedModel {
  const V = vocab.terms.length;
  const weights = new Float32Array(V);
  let bias = 0;
  const sparse = docs.map(d => sparseTfIdf(d, vocab));
  const y = labels.map(l => l === positiveClass ? 1 : -1);
  const n = docs.length;
  const totalBatches = epochs * Math.ceil(n / batchSize);
  let t = 1;
  let batchCount = 0;

  for (let ep = 0; ep < epochs; ep++) {
    const idx = Array.from({ length: n }, (_, i) => i);
    for (let i = n - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [idx[i], idx[j]] = [idx[j], idx[i]];
    }

    for (let b = 0; b < n; b += batchSize) {
      const batch = idx.slice(b, b + batchSize);
      const eta = 1 / (0.01 * t++);
      const shrink = Math.max(0, 1 - eta * 0.01);

      for (let j = 0; j < V; j++) weights[j] *= shrink;

      let biasGrad = 0;
      for (const i of batch) {
        const margin = y[i] * (sparseDot(sparse[i], weights) + bias);
        if (margin < 1) {
          const scale = (eta * C * y[i]) / batch.length;
          for (const [fi, fv] of sparse[i]) weights[fi] += scale * fv;
          biasGrad += y[i];
        }
      }
      bias += (eta * C * biasGrad) / batch.length;
      batchCount++;
      if (onProgress) onProgress(Math.round((batchCount / totalBatches) * 100));
    }
  }
  return {
    algo: "SVM", vocab, weights, bias, positiveClass,
    classes: [positiveClass, positiveClass === "FAKE" ? "REAL" : "FAKE"],
    logPrior: { [positiveClass]: 0, [positiveClass === "FAKE" ? "REAL" : "FAKE"]: 0 },
  };
}

// ─── Unified predict ──────────────────────────────────────────────────────────

function softmax(raw: Record<string, number>): Record<string, number> {
  const vals = Object.values(raw);
  const max = Math.max(...vals);
  const exps = Object.fromEntries(Object.entries(raw).map(([k, v]) => [k, Math.exp(v - max)]));
  const sum = Object.values(exps).reduce((a, b) => a + b, 0);
  return Object.fromEntries(Object.entries(exps).map(([k, v]) => [k, v / sum]));
}

export function predict(tokens: string[], model: TrainedModel): PredictResult {
  const sparse = sparseTfIdf(tokens, model.vocab);
  let probs: Record<string, number>;

  if (model.algo === "Naive Bayes") {
    const rawScores: Record<string, number> = {};
    for (const cls of model.classes!) {
      let s = model.logPrior![cls];
      for (const [i] of sparse) s += model.logLikelihood![cls][i];
      rawScores[cls] = s;
    }
    probs = softmax(rawScores);

  } else {
    // LR and SVM: decision value → sigmoid calibration
    const z = sparseDot(sparse, model.weights!) + (model.bias ?? 0);
    const p = sigmoid(model.algo === "SVM" ? z * 0.5 : z);
    const pos = model.positiveClass!;
    const neg = model.classes!.find(c => c !== pos) ?? (pos === "FAKE" ? "REAL" : "FAKE");
    probs = { [pos]: p, [neg]: 1 - p };
  }

  // Pick highest-probability label
  const label = Object.entries(probs).reduce(
    (best, [k, v]) => v > probs[best] ? k : best,
    Object.keys(probs)[0],
  );
  const confidence = Math.min(99, Math.max(51, Math.round(probs[label] * 100)));

  // Top discriminative features
  let topFeatures: { word: string; weight: number }[] = [];
  if (model.algo === "Naive Bayes") {
    const other = model.classes!.find(c => c !== label)!;
    topFeatures = sparse
      .map(([i, v]) => ({
        word: model.vocab.terms[i],
        weight: v * (model.logLikelihood![label][i] - (model.logLikelihood![other]?.[i] ?? 0)),
      }))
      .sort((a, b) => b.weight - a.weight)
      .slice(0, 12);
  } else {
    const sign = label === model.positiveClass ? 1 : -1;
    topFeatures = sparse
      .map(([i, v]) => ({ word: model.vocab.terms[i], weight: sign * model.weights![i] * v }))
      .sort((a, b) => b.weight - a.weight)
      .slice(0, 12);
  }

  return { label, confidence, scores: probs, topFeatures };
}

// ─── Evaluation ───────────────────────────────────────────────────────────────

export function evaluate(docs: string[][], labels: string[], model: TrainedModel): EvalResult {
  const classes = model.classes ?? ["FAKE", "REAL"];
  const cm: Record<string, Record<string, number>> = {};
  for (const a of classes) { cm[a] = {}; for (const p of classes) cm[a][p] = 0; }

  let correct = 0;
  for (let i = 0; i < docs.length; i++) {
    const res = predict(docs[i], model);
    if (res.label === labels[i]) correct++;
    if (cm[labels[i]]) cm[labels[i]][res.label] = (cm[labels[i]][res.label] || 0) + 1;
  }

  const precision: Record<string, number> = {};
  const recall: Record<string, number> = {};
  const f1: Record<string, number> = {};
  for (const cls of classes) {
    const tp = cm[cls]?.[cls] ?? 0;
    const fp = classes.reduce((s, c) => c !== cls ? s + (cm[c]?.[cls] ?? 0) : s, 0);
    const fn = classes.reduce((s, c) => c !== cls ? s + (cm[cls]?.[c] ?? 0) : s, 0);
    precision[cls] = tp / Math.max(1, tp + fp);
    recall[cls]    = tp / Math.max(1, tp + fn);
    f1[cls] = 2 * precision[cls] * recall[cls] / Math.max(1e-9, precision[cls] + recall[cls]);
  }

  return {
    accuracy: correct / Math.max(1, docs.length),
    precision, recall, f1, confusionMatrix: cm,
    samples: docs.length,
  };
}
